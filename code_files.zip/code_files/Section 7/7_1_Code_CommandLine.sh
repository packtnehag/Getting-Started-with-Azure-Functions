npm install -g azure-functions-core-tools

func azure storage list

mdkir AzureFunctionApp

func functionapp init

func function create
